const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/apiResponse');
const AppError = require('../utils/AppError');
const BulkEnquiry = require('../models/BulkEnquiry');
const { logAction } = require('../services/auditLog.service');
const { generateRefNumber } = require('../services/refNumber.service');
const {
  buildBulkEnquiryExcelBuffer,
  buildBulkEnquiryPdfBuffer,
} = require('../services/bulkEnquiryTemplate.service');
const { BULK_ENQUIRY_TEXT_EXAMPLE } = require('../constants/bulkEnquiryTemplate');

const genNumber = () => generateRefNumber('BULK_ENQUIRY');

const getAll = asyncHandler(async (req, res) => {
  const { status, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(100, parseInt(limit));
  const [items, total] = await Promise.all([
    BulkEnquiry.find(filter)
      .populate('customer', 'name email')
      .populate('assignedTo', 'name email')
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum),
    BulkEnquiry.countDocuments(filter),
  ]);
  return ApiResponse.success(res, 200, 'Bulk enquiries retrieved.', items, {
    total, page: pageNum, limit: limitNum, pages: Math.ceil(total / limitNum),
  });
});

const getById = asyncHandler(async (req, res) => {
  const item = await BulkEnquiry.findById(req.params.id)
    .populate('customer', 'name email phone')
    .populate('assignedTo', 'name email');
  if (!item) throw new AppError('Bulk enquiry not found.', 404);
  return ApiResponse.success(res, 200, 'Bulk enquiry retrieved.', item);
});

const create = asyncHandler(async (req, res) => {
  const attachments = Array.isArray(req.body.attachments) ? req.body.attachments : [];
  const isSandAggregatesQuote = req.body.quoteType === 'SAND_AGGREGATES';
  if (!attachments.length && !isSandAggregatesQuote) {
    throw new AppError('At least one document is required (PDF, image, or Excel).', 400);
  }
  if (!req.body.customerName?.trim() || !req.body.customerPhone?.trim()) {
    throw new AppError('Customer name and phone are required.', 400);
  }
  const enquiryNumber = await genNumber();
  const payload = {
    ...req.body,
    enquiryNumber,
    requirement: req.body.requirement?.trim() || 'See attached document(s)',
    attachments,
  };
  if (req.user?._id) payload.customer = req.user._id;
  const item = await BulkEnquiry.create(payload);
  return ApiResponse.created(res, 'Bulk enquiry submitted.', item);
});

const update = asyncHandler(async (req, res) => {
  const item = await BulkEnquiry.findById(req.params.id);
  if (!item) throw new AppError('Bulk enquiry not found.', 404);
  const allowed = ['status', 'assignedTo', 'adminNotes'];
  allowed.forEach(f => { if (req.body[f] !== undefined) item[f] = req.body[f]; });
  await item.save();
  await item.populate('assignedTo', 'name email');
  await logAction({ adminId: req.user._id, action: 'UPDATE', module: 'BulkEnquiry',
    targetId: item._id.toString(), description: `Updated bulk enquiry: ${item.enquiryNumber}`, ipAddress: req.ip });
  return ApiResponse.success(res, 200, 'Bulk enquiry updated.', item);
});

const getStats = asyncHandler(async (req, res) => {
  const [total, newEnq, inProgress, quoted, converted] = await Promise.all([
    BulkEnquiry.countDocuments(),
    BulkEnquiry.countDocuments({ status: 'NEW' }),
    BulkEnquiry.countDocuments({ status: 'IN_PROGRESS' }),
    BulkEnquiry.countDocuments({ status: 'QUOTED' }),
    BulkEnquiry.countDocuments({ status: 'CONVERTED' }),
  ]);
  return ApiResponse.success(res, 200, 'Stats.', { total, new: newEnq, inProgress, quoted, converted });
});

const downloadExcelTemplate = asyncHandler(async (req, res) => {
  const buffer = await buildBulkEnquiryExcelBuffer();
  res.setHeader(
    'Content-Type',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  );
  res.setHeader(
    'Content-Disposition',
    'attachment; filename="structbay-bulk-enquiry-template.xlsx"'
  );
  res.send(Buffer.from(buffer));
});

const downloadPdfTemplate = asyncHandler(async (req, res) => {
  const buffer = await buildBulkEnquiryPdfBuffer();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    'attachment; filename="structbay-bulk-enquiry-template.pdf"'
  );
  res.send(buffer);
});

const getTextExample = asyncHandler(async (req, res) => {
  return ApiResponse.success(res, 200, 'Bulk enquiry text example.', {
    example: BULK_ENQUIRY_TEXT_EXAMPLE,
  });
});

module.exports = {
  getAll,
  getById,
  create,
  update,
  getStats,
  downloadExcelTemplate,
  downloadPdfTemplate,
  getTextExample,
};
