const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/apiResponse');
const AppError = require('../utils/AppError');
const User = require('../models/User');
const RefreshToken = require('../models/tokens/RefreshToken');
const Session = require('../models/Session');
const { ROLES, USER_STATUS, VENDOR_STATUS, PAGINATION } = require('../config/constants');
const { logAction } = require('../services/auditLog.service');
const {
  sendVendorApprovedEmail,
  sendVendorRejectedEmail,
} = require('../services/email.service');

const authService = require('../services/auth.service');

// ─── GET /api/v1/admin/users ──────────────────────────────────────────────────
const getAllUsers = asyncHandler(async (req, res) => {
  const {
    page = PAGINATION.DEFAULT_PAGE,
    limit = PAGINATION.DEFAULT_LIMIT,
    role,
    status,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
  } = req.query;

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(parseInt(limit), PAGINATION.MAX_LIMIT);
  const skip = (pageNum - 1) * limitNum;

  const filter = {};
  if (role) filter.role = role;
  if (status) filter.status = status;
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
      { phone: { $regex: search, $options: 'i' } },
      { companyName: { $regex: search, $options: 'i' } },
    ];
  }

  const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

  const [users, total] = await Promise.all([
    User.find(filter).sort(sort).skip(skip).limit(limitNum),
    User.countDocuments(filter),
  ]);

  return ApiResponse.success(
    res,
    200,
    'Users retrieved.',
    users,
    {
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum),
    }
  );
});

// ─── GET /api/v1/admin/users/:id ─────────────────────────────────────────────
const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new AppError('User not found.', 404);
  return ApiResponse.success(res, 200, 'User retrieved.', user);
});

// ─── PUT /api/v1/admin/users/:id/status ───────────────────────────────────────
const updateUserStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!Object.values(USER_STATUS).includes(status)) {
    throw new AppError(`Invalid status. Must be one of: ${Object.values(USER_STATUS).join(', ')}`, 400);
  }

  const user = await User.findByIdAndUpdate(
    req.params.id,
    { status },
    { new: true }
  );
  if (!user) throw new AppError('User not found.', 404);

  // On suspend/delete, revoke all tokens
  if (status === USER_STATUS.SUSPENDED || status === USER_STATUS.DELETED) {
    await RefreshToken.revokeAllForUser(user._id);
    await Session.updateMany({ user: user._id, isActive: true }, { isActive: false, logoutAt: new Date() });
  }

  return ApiResponse.success(res, 200, `User status updated to ${status}.`, user);
});

// ─── DELETE /api/v1/admin/users/:id ──────────────────────────────────────────
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new AppError('User not found.', 404);

  await RefreshToken.revokeAllForUser(user._id);
  await Promise.all([
    Session.deleteMany({ user: user._id }),
    RefreshToken.deleteMany({ user: user._id }),
    User.deleteOne({ _id: user._id }),
  ]);

  return ApiResponse.success(res, 200, 'User deleted successfully.');
});

// ─── PUT /api/v1/admin/vendors/:id/approve ────────────────────────────────────
const approveVendor = asyncHandler(async (req, res) => {
  const vendor = await User.findOne({ _id: req.params.id, role: 'VENDOR' });
  if (!vendor) throw new AppError('Vendor not found.', 404);

  if (vendor.vendorStatus === VENDOR_STATUS.APPROVED) {
    throw new AppError('Vendor is already approved.', 400);
  }

  vendor.vendorStatus = VENDOR_STATUS.APPROVED;
  vendor.status = USER_STATUS.ACTIVE;
  vendor.isEmailVerified = true;
  vendor.vendorApprovedBy = req.user._id;
  vendor.vendorApprovedAt = new Date();
  vendor.vendorRejectionReason = null;
  if (!vendor.referenceNumber) {
    const { generateRefNumber } = require('../services/refNumber.service');
    try {
      vendor.referenceNumber = await generateRefNumber('VENDOR');
    } catch {
      /* non-blocking */
    }
  }
  await vendor.save({ validateBeforeSave: false });

  await sendVendorApprovedEmail({
    to: vendor.email,
    name: vendor.name,
    companyName: vendor.companyName,
  });

  return ApiResponse.success(res, 200, 'Vendor approved successfully.', {
    id: vendor._id,
    name: vendor.name,
    vendorStatus: vendor.vendorStatus,
    status: vendor.status,
  });
});

// ─── PUT /api/v1/admin/vendors/:id/reject ─────────────────────────────────────
const rejectVendor = asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const vendor = await User.findOne({ _id: req.params.id, role: 'VENDOR' });
  if (!vendor) throw new AppError('Vendor not found.', 404);

  vendor.vendorStatus = VENDOR_STATUS.REJECTED;
  vendor.status = USER_STATUS.REJECTED;
  vendor.vendorRejectionReason = reason || null;
  await vendor.save({ validateBeforeSave: false });

  await sendVendorRejectedEmail({
    to: vendor.email,
    name: vendor.name,
    companyName: vendor.companyName,
    reason,
  });

  return ApiResponse.success(res, 200, 'Vendor rejected.', {
    id: vendor._id,
    name: vendor.name,
    vendorStatus: vendor.vendorStatus,
  });
});

// ─── GET /api/v1/admin/vendors ────────────────────────────────────────────────
const getAllVendors = asyncHandler(async (req, res) => {
  const {
    page = PAGINATION.DEFAULT_PAGE,
    limit = PAGINATION.DEFAULT_LIMIT,
    vendorStatus,
    search,
  } = req.query;

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(parseInt(limit), PAGINATION.MAX_LIMIT);
  const skip = (pageNum - 1) * limitNum;

  const filter = { role: 'VENDOR', status: { $ne: USER_STATUS.DELETED } };
  const andParts = [];

  /** Dropdowns (e.g. order assignment) use APPROVED — include legacy rows with null vendorStatus but active account. */
  if (vendorStatus === 'APPROVED') {
    andParts.push({
      $or: [
        { vendorStatus: 'APPROVED' },
        { vendorStatus: null, status: 'ACTIVE' },
      ],
    });
  } else if (vendorStatus) {
    andParts.push({ vendorStatus });
  }

  if (search) {
    andParts.push({
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { companyName: { $regex: search, $options: 'i' } },
        { gstNumber: { $regex: search, $options: 'i' } },
      ],
    });
  }

  if (andParts.length === 1) Object.assign(filter, andParts[0]);
  else if (andParts.length > 1) filter.$and = andParts;

  const [vendors, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limitNum),
    User.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Vendors retrieved.', vendors, {
    total,
    page: pageNum,
    limit: limitNum,
    totalPages: Math.ceil(total / limitNum),
  });
});

// ─── POST /api/v1/admin/vendors ───────────────────────────────────────────────
const createVendor = asyncHandler(async (req, res) => {
  const {
    name, email, phone, password, companyName, contactPerson, gstNumber, businessRegNumber,
    companyAddress, warehouseAddress, contactPersonName, contactPersonPhone, bankDetails
  } = req.body;

  // 1. Email check
  const emailNorm = String(email || '').trim().toLowerCase();
  const existingEmail = await User.findOne({ email: emailNorm, status: { $ne: 'DELETED' } });
  if (existingEmail) throw new AppError('An account with this email already exists.', 409);

  // 2. GST check
  if (gstNumber && String(gstNumber).trim()) {
    const gstNorm = String(gstNumber).trim().toUpperCase();
    const existingGst = await User.findOne({
      role: 'VENDOR',
      gstNumber: gstNorm,
      status: { $ne: 'DELETED' }
    });
    if (existingGst) throw new AppError('A vendor with this GST number already exists.', 409);
  }

  // 3. Create using authService
  const user = await authService.createVendorByAdmin(req.body, req.user);

  // 4. Update the newly created user with the extended fields
  user.companyAddress = companyAddress || null;
  user.warehouseAddress = warehouseAddress || null;
  user.contactPersonName = contactPersonName || contactPerson || name || null;
  user.contactPersonPhone = contactPersonPhone || phone || null;
  user.cancelledChequeFile = null;

  if (bankDetails) {
    user.bankDetails = {
      accountHolderName: bankDetails.accountHolderName || null,
      bankName: bankDetails.bankName || null,
      accountNumber: bankDetails.accountNumber || null,
      ifscCode: bankDetails.ifscCode ? bankDetails.ifscCode.toUpperCase() : null,
      branch: bankDetails.branchName || null,
      branchName: bankDetails.branchName || null,
      cancelledChequeFile: null
    };
  } else {
    user.bankDetails = {
      accountHolderName: null,
      bankName: null,
      accountNumber: null,
      ifscCode: null,
      branch: null,
      branchName: null,
      cancelledChequeFile: null
    };
  }

  await user.save({ validateBeforeSave: false });

  // 5. Create or sync legacy Vendor document (for compatibility with existing flows)
  try {
    const Vendor = require('../models/Vendor');
    let legacyVendor = await Vendor.findOne({ email: emailNorm });
    if (!legacyVendor) {
      legacyVendor = new Vendor({
        email: emailNorm,
        password: user.password,
        companyName: companyName,
        contactPerson: contactPerson || name,
        phone: phone,
        gstNumber: gstNumber ? String(gstNumber).trim().toUpperCase() : '—',
        panNumber: req.body.panNumber || '—',
        referenceNumber: user.referenceNumber,
        status: 'active',
        verificationStatus: 'verified'
      });
    }

    legacyVendor.companyAddress = companyAddress || null;
    legacyVendor.warehouseAddress = warehouseAddress || null;
    legacyVendor.contactPersonName = contactPersonName || contactPerson || name || null;
    legacyVendor.contactPersonPhone = contactPersonPhone || phone || null;
    legacyVendor.cancelledChequeFile = null;

    if (bankDetails) {
      legacyVendor.bankDetails = {
        accountHolderName: bankDetails.accountHolderName || null,
        bankName: bankDetails.bankName || null,
        accountNumber: bankDetails.accountNumber || null,
        ifscCode: bankDetails.ifscCode ? bankDetails.ifscCode.toUpperCase() : null,
        branch: bankDetails.branchName || null,
        branchName: bankDetails.branchName || null,
        cancelledChequeFile: null
      };
    } else {
      legacyVendor.bankDetails = {
        accountHolderName: null,
        bankName: null,
        accountNumber: null,
        ifscCode: null,
        branch: null,
        branchName: null,
        cancelledChequeFile: null
      };
    }

    await legacyVendor.save();
  } catch (err) {
    console.error('Failed to create legacy vendor record:', err);
  }

  return ApiResponse.created(
    res,
    'Vendor account created. They can sign in with the password you set.',
    user
  );
});

// ─── GET /api/v1/admin/vendors/:id ─────────────────────────────────────────────
const getVendorById = asyncHandler(async (req, res) => {
  const vendor = await User.findOne({ _id: req.params.id, role: 'VENDOR' });
  if (!vendor) throw new AppError('Vendor not found.', 404);
  return ApiResponse.success(res, 200, 'Vendor retrieved.', vendor);
});

// ─── PUT /api/v1/admin/vendors/:id ─────────────────────────────────────────────
const updateVendor = asyncHandler(async (req, res) => {
  const vendor = await User.findOne({ _id: req.params.id, role: 'VENDOR' });
  if (!vendor) throw new AppError('Vendor not found.', 404);

  const {
    name, email, phone, companyName, contactPerson, gstNumber, businessRegNumber,
    companyAddress, warehouseAddress, contactPersonName, contactPersonPhone, bankDetails,
    vendorStatus, status, vendorCode
  } = req.body;

  // 1. Email check
  if (email && email.toLowerCase() !== vendor.email.toLowerCase()) {
    const emailNorm = email.toLowerCase();
    const existingEmail = await User.findOne({
      email: emailNorm,
      _id: { $ne: vendor._id },
      status: { $ne: 'DELETED' }
    });
    if (existingEmail) throw new AppError('An account with this email already exists.', 409);
    vendor.email = emailNorm;
  }

  // 2. GST check
  if (gstNumber && (!vendor.gstNumber || gstNumber.toUpperCase() !== vendor.gstNumber.toUpperCase())) {
    const gstNorm = gstNumber.trim().toUpperCase();
    const existingGst = await User.findOne({
      role: 'VENDOR',
      gstNumber: gstNorm,
      _id: { $ne: vendor._id },
      status: { $ne: 'DELETED' }
    });
    if (existingGst) throw new AppError('A vendor with this GST number already exists.', 409);
    vendor.gstNumber = gstNorm;
  } else if (gstNumber === '') {
    vendor.gstNumber = null;
  }

  // 3. Update basic fields
  if (name !== undefined) vendor.name = name;
  if (phone !== undefined) vendor.phone = phone;
  if (companyName !== undefined) vendor.companyName = companyName;
  if (contactPerson !== undefined) vendor.contactPerson = contactPerson;
  if (businessRegNumber !== undefined) vendor.businessRegNumber = businessRegNumber || null;
  if (vendorCode !== undefined && String(vendorCode).trim() !== '') {
    const codeNorm = String(vendorCode).trim().toUpperCase();
    if (codeNorm !== (vendor.referenceNumber || '').toUpperCase()) {
      const existingRef = await User.findOne({
        referenceNumber: codeNorm,
        _id: { $ne: vendor._id },
      });
      if (existingRef) throw new AppError('This Vendor Code is already in use.', 409);
      vendor.referenceNumber = codeNorm;
    }
  }

  // 4. Update new extended fields
  if (companyAddress !== undefined) vendor.companyAddress = companyAddress || null;
  if (warehouseAddress !== undefined) vendor.warehouseAddress = warehouseAddress || null;
  if (contactPersonName !== undefined) vendor.contactPersonName = contactPersonName || null;
  if (contactPersonPhone !== undefined) vendor.contactPersonPhone = contactPersonPhone || null;

  // 5. Update bankDetails
  if (bankDetails) {
    if (!vendor.bankDetails) vendor.bankDetails = {};
    if (bankDetails.accountHolderName !== undefined) vendor.bankDetails.accountHolderName = bankDetails.accountHolderName || null;
    if (bankDetails.bankName !== undefined) vendor.bankDetails.bankName = bankDetails.bankName || null;
    if (bankDetails.accountNumber !== undefined) vendor.bankDetails.accountNumber = bankDetails.accountNumber || null;
    if (bankDetails.ifscCode !== undefined) vendor.bankDetails.ifscCode = bankDetails.ifscCode ? bankDetails.ifscCode.toUpperCase() : null;
    if (bankDetails.branchName !== undefined) {
      vendor.bankDetails.branchName = bankDetails.branchName || null;
      vendor.bankDetails.branch = bankDetails.branchName || null;
    }
  }

  // 6. Update status if changed
  if (vendorStatus !== undefined) vendor.vendorStatus = vendorStatus;
  if (status !== undefined) {
    vendor.status = status;
    if (status === 'SUSPENDED' || status === 'DELETED') {
      const RefreshToken = require('../models/tokens/RefreshToken');
      const Session = require('../models/Session');
      await RefreshToken.revokeAllForUser(vendor._id);
      await Session.updateMany({ user: vendor._id, isActive: true }, { isActive: false, logoutAt: new Date() });
    }
  }

  await vendor.save({ validateBeforeSave: false });

  // 7. Sync to legacy Vendor collection
  try {
    const Vendor = require('../models/Vendor');
    let legacyVendor = await Vendor.findOne({ email: vendor.email });
    if (!legacyVendor && email) {
      legacyVendor = await Vendor.findOne({ email: email });
    }

    if (legacyVendor) {
      if (email) legacyVendor.email = email.toLowerCase();
      if (name) legacyVendor.contactPerson = name;
      if (phone) legacyVendor.phone = phone;
      if (companyName) legacyVendor.companyName = companyName;
      if (gstNumber) legacyVendor.gstNumber = gstNumber.toUpperCase();
      if (vendorCode !== undefined && String(vendorCode).trim() !== '') {
        legacyVendor.referenceNumber = String(vendorCode).trim().toUpperCase();
      }
      if (companyAddress !== undefined) legacyVendor.companyAddress = companyAddress || null;
      if (warehouseAddress !== undefined) legacyVendor.warehouseAddress = warehouseAddress || null;
      if (contactPersonName !== undefined) legacyVendor.contactPersonName = contactPersonName || null;
      if (contactPersonPhone !== undefined) legacyVendor.contactPersonPhone = contactPersonPhone || null;
      
      if (bankDetails) {
        if (!legacyVendor.bankDetails) legacyVendor.bankDetails = {};
        if (bankDetails.accountHolderName !== undefined) legacyVendor.bankDetails.accountHolderName = bankDetails.accountHolderName || null;
        if (bankDetails.bankName !== undefined) legacyVendor.bankDetails.bankName = bankDetails.bankName || null;
        if (bankDetails.accountNumber !== undefined) legacyVendor.bankDetails.accountNumber = bankDetails.accountNumber || null;
        if (bankDetails.ifscCode !== undefined) legacyVendor.bankDetails.ifscCode = bankDetails.ifscCode ? bankDetails.ifscCode.toUpperCase() : null;
        if (bankDetails.branchName !== undefined) {
          legacyVendor.bankDetails.branchName = bankDetails.branchName || null;
          legacyVendor.bankDetails.branch = bankDetails.branchName || null;
        }
      }

      if (vendorStatus) {
        if (vendorStatus === 'APPROVED') legacyVendor.verificationStatus = 'verified';
        else if (vendorStatus === 'REJECTED') legacyVendor.verificationStatus = 'rejected';
      }
      if (status) {
        if (status === 'ACTIVE') legacyVendor.status = 'active';
        else if (status === 'SUSPENDED') legacyVendor.status = 'suspended';
      }

      await legacyVendor.save();
    }
  } catch (err) {
    console.error('Failed to sync update to legacy vendor:', err);
  }

  return ApiResponse.success(res, 200, 'Vendor updated successfully.', vendor);
});

// ─── POST /api/v1/admin/vendors/:id/documents ─────────────────────────────────────
const uploadCancelledCheque = asyncHandler(async (req, res) => {
  const vendor = await User.findOne({ _id: req.params.id, role: 'VENDOR' });
  if (!vendor) throw new AppError('Vendor not found.', 404);
  if (!req.file) throw new AppError('No file uploaded.', 400);

  const fileUrl = req.file.path;
  vendor.cancelledChequeFile = fileUrl;
  if (!vendor.bankDetails) vendor.bankDetails = {};
  vendor.bankDetails.cancelledChequeFile = fileUrl;

  await vendor.save({ validateBeforeSave: false });

  // Sync to legacy Vendor collection
  try {
    const Vendor = require('../models/Vendor');
    const legacyVendor = await Vendor.findOne({ email: vendor.email });
    if (legacyVendor) {
      legacyVendor.cancelledChequeFile = fileUrl;
      if (!legacyVendor.bankDetails) legacyVendor.bankDetails = {};
      legacyVendor.bankDetails.cancelledChequeFile = fileUrl;
      await legacyVendor.save();
    }
  } catch (err) {
    console.error('Failed to sync cancelled cheque to legacy vendor:', err);
  }

  return ApiResponse.success(res, 200, 'Cancelled cheque uploaded successfully.', {
    cancelledChequeFile: fileUrl
  });
});


const BULK_DELETE_MAX = 200;

const deleteVendor = asyncHandler(async (req, res) => {
  const vendor = await User.findOne({ _id: req.params.id, role: ROLES.VENDOR });
  if (!vendor) throw new AppError('Vendor not found.', 404);
  await RefreshToken.revokeAllForUser(vendor._id);
  await Promise.all([
    Session.deleteMany({ user: vendor._id }),
    RefreshToken.deleteMany({ user: vendor._id }),
    User.deleteOne({ _id: vendor._id }),
  ]);
  await logAction({
    adminId: req.user._id,
    action: 'DELETE',
    module: 'Vendor',
    targetId: vendor._id.toString(),
    description: `Deleted vendor ${vendor.companyName || vendor.name}`,
    ipAddress: req.ip,
  });
  return ApiResponse.success(res, 200, 'Vendor deleted successfully.');
});

const bulkDeleteVendors = asyncHandler(async (req, res) => {
  const raw = req.body?.ids;
  const ids = Array.isArray(raw) ? raw.map((x) => String(x).trim()).filter(Boolean) : [];
  if (!ids.length) throw new AppError('No valid vendor ids provided.', 400);
  if (ids.length > BULK_DELETE_MAX) {
    throw new AppError(`Too many ids (max ${BULK_DELETE_MAX}).`, 400);
  }

  const errors = [];
  let ok = 0;
  for (const id of ids) {
    try {
      const vendor = await User.findOne({ _id: id, role: ROLES.VENDOR });
      if (!vendor) throw new AppError('Vendor not found.', 404);
      await RefreshToken.revokeAllForUser(vendor._id);
      await Promise.all([
        Session.deleteMany({ user: vendor._id }),
        RefreshToken.deleteMany({ user: vendor._id }),
        User.deleteOne({ _id: vendor._id }),
      ]);
      ok += 1;
    } catch (e) {
      errors.push({
        id,
        message: e instanceof AppError ? e.message : (e && e.message) || String(e),
      });
    }
  }

  await logAction({
    adminId: req.user._id,
    action: 'DELETE',
    module: 'Vendor',
    targetId: ids.slice(0, 20).join(','),
    description: `Bulk deleted ${ok} vendor(s)${errors.length ? `; ${errors.length} failed` : ''}`,
    ipAddress: req.ip,
  });

  return ApiResponse.success(res, 200, `Deleted ${ok} vendor(s).`, {
    total: ids.length,
    succeeded: ok,
    failed: errors.length,
    errors,
  });
});

// ─── POST /api/v1/admin/admins ───────────────────────────────────────────────
const createAdmin = asyncHandler(async (req, res) => {
  const { name, email, phone, password, confirmPassword, role, status } = req.body;

  // Validation
  if (!name || !name.trim()) throw new AppError('Name is required.', 400);
  if (!email || !email.trim()) throw new AppError('Email is required.', 400);
  if (!password || !password.trim()) throw new AppError('Password is required.', 400);
  if (!confirmPassword || !confirmPassword.trim()) throw new AppError('Confirm Password is required.', 400);
  if (password !== confirmPassword) throw new AppError('Passwords do not match.', 400);
  if (password.length < 8) throw new AppError('Password must be at least 8 characters.', 400);

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) throw new AppError('Invalid email address.', 400);

  // Check email uniqueness
  const emailNorm = email.trim().toLowerCase();
  const existingEmail = await User.findOne({ email: emailNorm, status: { $ne: USER_STATUS.DELETED } });
  if (existingEmail) throw new AppError('An account with this email already exists.', 409);

  // Create admin
  const user = await authService.createAdminByAdmin(
    {
      name: name.trim(),
      email: emailNorm,
      phone: phone ? phone.trim() : null,
      password,
      role: role || ROLES.ADMIN,
      status: status || USER_STATUS.ACTIVE,
    },
    req.user
  );

  // Log action
  await logAction({
    adminId: req.user._id,
    action: 'CREATE',
    module: 'Admin',
    targetId: user._id.toString(),
    description: `Created admin account for ${user.name} (${user.email})`,
    ipAddress: req.ip,
  });

  return ApiResponse.created(res, 'Admin account created successfully.', user);
});

// ─── GET /api/v1/admin/admins ─────────────────────────────────────────────────
const getAllAdmins = asyncHandler(async (req, res) => {
  const {
    page = PAGINATION.DEFAULT_PAGE,
    limit = PAGINATION.DEFAULT_LIMIT,
    status,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
  } = req.query;

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(parseInt(limit), PAGINATION.MAX_LIMIT);
  const skip = (pageNum - 1) * limitNum;

  const filter = { role: ROLES.ADMIN };
  if (status) filter.status = status;
  if (search) {
    filter.$or = [
      { name: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
      { phone: { $regex: search, $options: 'i' } },
    ];
  }

  const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

  const [admins, total] = await Promise.all([
    User.find(filter).sort(sort).skip(skip).limit(limitNum),
    User.countDocuments(filter),
  ]);

  return ApiResponse.success(
    res,
    200,
    'Admins retrieved.',
    admins,
    {
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum),
    }
  );
});

// ─── GET /api/v1/admin/admins/:id ─────────────────────────────────────────────
const getAdminById = asyncHandler(async (req, res) => {
  const admin = await User.findOne({ _id: req.params.id, role: ROLES.ADMIN });
  if (!admin) throw new AppError('Admin not found.', 404);
  return ApiResponse.success(res, 200, 'Admin retrieved.', admin);
});

// ─── PUT /api/v1/admin/admins/:id ─────────────────────────────────────────────
const updateAdmin = asyncHandler(async (req, res) => {
  const admin = await User.findOne({ _id: req.params.id, role: ROLES.ADMIN });
  if (!admin) throw new AppError('Admin not found.', 404);

  const { name, email, phone, status } = req.body;

  // Email uniqueness check
  if (email && email.toLowerCase() !== admin.email.toLowerCase()) {
    const emailNorm = email.toLowerCase();
    const existingEmail = await User.findOne({
      email: emailNorm,
      _id: { $ne: admin._id },
      status: { $ne: USER_STATUS.DELETED },
    });
    if (existingEmail) throw new AppError('An account with this email already exists.', 409);
    admin.email = emailNorm;
  }

  if (name !== undefined) admin.name = name.trim();
  if (phone !== undefined) admin.phone = phone ? phone.trim() : null;
  if (status !== undefined) {
    admin.status = status;
    if (status === USER_STATUS.SUSPENDED || status === USER_STATUS.DELETED) {
      await RefreshToken.revokeAllForUser(admin._id);
      await Session.updateMany({ user: admin._id, isActive: true }, { isActive: false, logoutAt: new Date() });
    }
  }

  await admin.save({ validateBeforeSave: false });

  await logAction({
    adminId: req.user._id,
    action: 'UPDATE',
    module: 'Admin',
    targetId: admin._id.toString(),
    description: `Updated admin account for ${admin.name}`,
    ipAddress: req.ip,
  });

  return ApiResponse.success(res, 200, 'Admin updated successfully.', admin);
});

// ─── PUT /api/v1/admin/admins/:id/status ──────────────────────────────────────
const updateAdminStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!Object.values(USER_STATUS).includes(status)) {
    throw new AppError(`Invalid status. Must be one of: ${Object.values(USER_STATUS).join(', ')}`, 400);
  }

  const admin = await User.findOne({ _id: req.params.id, role: ROLES.ADMIN });
  if (!admin) throw new AppError('Admin not found.', 404);

  admin.status = status;
  if (status === USER_STATUS.SUSPENDED || status === USER_STATUS.DELETED) {
    await RefreshToken.revokeAllForUser(admin._id);
    await Session.updateMany({ user: admin._id, isActive: true }, { isActive: false, logoutAt: new Date() });
  }

  await admin.save({ validateBeforeSave: false });

  await logAction({
    adminId: req.user._id,
    action: 'UPDATE',
    module: 'Admin',
    targetId: admin._id.toString(),
    description: `Changed admin status to ${status}`,
    ipAddress: req.ip,
  });

  return ApiResponse.success(res, 200, `Admin status updated to ${status}.`, admin);
});

// ─── POST /api/v1/admin/admins/:id/reset-password ────────────────────────────
const resetAdminPassword = asyncHandler(async (req, res) => {
  const { newPassword, confirmPassword } = req.body;

  if (!newPassword || !newPassword.trim()) throw new AppError('New password is required.', 400);
  if (!confirmPassword || !confirmPassword.trim()) throw new AppError('Confirm password is required.', 400);
  if (newPassword !== confirmPassword) throw new AppError('Passwords do not match.', 400);
  if (newPassword.length < 8) throw new AppError('Password must be at least 8 characters.', 400);

  const admin = await User.findOne({ _id: req.params.id, role: ROLES.ADMIN }).select('+password');
  if (!admin) throw new AppError('Admin not found.', 404);

  admin.password = newPassword;
  await admin.save();

  // Revoke all sessions
  await RefreshToken.revokeAllForUser(admin._id);
  await Session.updateMany({ user: admin._id, isActive: true }, { isActive: false, logoutAt: new Date() });

  await logAction({
    adminId: req.user._id,
    action: 'UPDATE',
    module: 'Admin',
    targetId: admin._id.toString(),
    description: `Reset password for admin ${admin.name}`,
    ipAddress: req.ip,
  });

  return ApiResponse.success(res, 200, 'Admin password reset successfully.');
});

// ─── DELETE /api/v1/admin/admins/:id ──────────────────────────────────────────
const deleteAdmin = asyncHandler(async (req, res) => {
  const admin = await User.findOne({ _id: req.params.id, role: ROLES.ADMIN });
  if (!admin) throw new AppError('Admin not found.', 404);

  await RefreshToken.revokeAllForUser(admin._id);
  await Promise.all([
    Session.deleteMany({ user: admin._id }),
    RefreshToken.deleteMany({ user: admin._id }),
    User.deleteOne({ _id: admin._id }),
  ]);

  await logAction({
    adminId: req.user._id,
    action: 'DELETE',
    module: 'Admin',
    targetId: admin._id.toString(),
    description: `Deleted admin account for ${admin.name}`,
    ipAddress: req.ip,
  });

  return ApiResponse.success(res, 200, 'Admin deleted successfully.');
});

module.exports = {
  getAllUsers,
  getUserById,
  updateUserStatus,
  deleteUser,
  approveVendor,
  rejectVendor,
  getAllVendors,
  createVendor,
  getVendorById,
  updateVendor,
  uploadCancelledCheque,
  deleteVendor,
  bulkDeleteVendors,
  createAdmin,
  getAllAdmins,
  getAdminById,
  updateAdmin,
  updateAdminStatus,
  resetAdminPassword,
  deleteAdmin,
};
